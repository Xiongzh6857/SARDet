import os
import json
 
input_file = 'D:/vscode/SARDet_detection/ultralytics-main/datasets/labels/val.txt'  # 输入文件名
output_dir = 'D:/vscode/SARDet_detection/ultralytics-main/datasets/labels/val'  # 输出文件夹
 
# 确保输出目录存在
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
 
with open(input_file, 'r') as f:
    data_dict = json.load(f)
images = data_dict["images"]
annotations = data_dict["annotations"]
for image in images:
    name = image["file_name"]
    ns = name.split('.')
    n = ns[0]
    id = image["id"]
    h = image["height"]
    w = image["width"]
    with open(os.path.join(output_dir, f'{n}.txt'), 'w') as out_file:
        for annotation in annotations:
            if annotation["image_id"] == id:
                category_id = annotation["category_id"]
                x_center, y_center, width, height = annotation['bbox']
                x_center = (x_center + width / 2) / w  # offset and scale
                y_center = (y_center + height / 2) / h  # offset and scale
                width /= w  # scale
                height /= h  # scale
                out_file.write(f"{category_id} {x_center} {y_center} {width} {height}\n")